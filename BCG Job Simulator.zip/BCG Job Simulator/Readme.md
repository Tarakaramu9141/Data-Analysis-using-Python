# BCG Job Simulator by Forage

This repository contains my experience from the BCG Job Simulator of a Data Analyst offered by Forage. The simulation provides a practical overview of the practical tasks and offers hands-on experience in the Data Analytics Job role.

There are total of 4 Tasks

Task 1: Business Understanding and Hypothesis Framing.
Task 2: Exploratory Data Analysis.
Task 3: Feature Engineering and Modelling.
Task 4: Findings and Recommendations.

# Task 1

The first task will be understanding the client needs and asking them about sharing the information about their past 5 years data of their customer's service feedback, company growth, etc., through email.



# Task 2

In the second task, the client sends the 2 datasets i.e. (price_data.csv, client_data.csv) as a reply for our mail. We need to analyze the Exploratory data analysis of the given datasets and submit the notebook file.

# Task 3

You will be given another dataset i.e.(clean_data_after_eda.csv) which is an normalised data without any null or duplicate values.
We have to create new features for your analysis like expand the datasets and use existing columns to create new features, combine some columns together to create 'better' columns, and submit our notebook file.

# Task 4

The 4th task will be training your dataset for predicting the churn and evaluate the prediction using the evaluation metrics to demonstrate how accurately the model has performed, you will be given new dataset i.e.(data_for_predictions.csv).

I have used Random forest algorithm for training the data. A random forest is a supervised learning algorithm which means that hyou must provide the algorithm with a set of features. 

It uses decision trees for predicting. We can also decide number of decision trees, for this case i have taken 100 decision trees.

We calculate the estimated benefits and costs of intervention
Under the assumptions provided, we can consider the impact of offering discounts to customers on revenue retention and potential loss due to false positives. Let's analyze these effects:

True Positives: Customers who would have churned but are retained due to the discount. In this scenario, the revenue is retained, resulting in revenue retention compared to the no-discount scenario. The retained revenue is calculated as 0.8 times the base case revenue (1 - discount_fraction).

False Positives: Customers who are offered a discount but would not have churned otherwise. Giving these customers a discount results in reduced revenue since they would have stayed without the discount. The loss in revenue is equal to the discount applied to these customers.

It's important to note that the assumption of all customers accepting the discount might not hold true in reality. Additionally, the accuracy of identifying true positives and false positives is dependent on the quality of the model and the observed dependent variable.

Overall, offering discounts can have a trade-off between revenue retention for true positives and potential revenue loss for false positives. Balancing these effects and optimizing the discount strategy is crucial to maximize revenue and minimize unnecessary discount.

# Conclusion
The Final result of this task is will calcuate the following case.

Maximum benefit at cutoff 0.5 with revenue delta of $7,766.71
